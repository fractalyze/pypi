# Copyright 2018 The JAX Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Note: import <name> as <name> is required for names to be exported.
# See PEP 484 & https://github.com/jax-ml/jax/issues/7570

from jax._src.basearray import Array as ndarray  # noqa: F401

from jax._src.dtypes import (
    isdtype as isdtype,
)

from jax._src.numpy.array_constructors import (
    array as array,
    asarray as asarray,
)

from jax._src.numpy.lax_numpy import (
    ComplexWarning as ComplexWarning,
    append as append,
    apply_along_axis as apply_along_axis,
    apply_over_axes as apply_over_axes,
    arange as arange,
    argmax as argmax,
    argmin as argmin,
    argwhere as argwhere,
    array_equal as array_equal,
    array_equiv as array_equiv,
    array_split as array_split,
    astype as astype,
    atleast_1d as atleast_1d,
    atleast_2d as atleast_2d,
    atleast_3d as atleast_3d,
    bincount as bincount,
    block as block,
    broadcast_arrays as broadcast_arrays,
    broadcast_shapes as broadcast_shapes,
    broadcast_to as broadcast_to,
    can_cast as can_cast,
    choose as choose,
    clip as clip,
    column_stack as column_stack,
    compress as compress,
    concat as concat,
    concatenate as concatenate,
    copy as copy,
    delete as delete,
    diag as diag,
    diagflat as diagflat,
    diag_indices as diag_indices,
    diag_indices_from as diag_indices_from,
    diagonal as diagonal,
    diff as diff,
    digitize as digitize,
    dsplit as dsplit,
    dstack as dstack,
    ediff1d as ediff1d,
    expand_dims as expand_dims,
    extract as extract,
    eye as eye,
    fill_diagonal as fill_diagonal,
    flatnonzero as flatnonzero,
    flip as flip,
    fliplr as fliplr,
    flipud as flipud,
    frombuffer as frombuffer,
    fromfile as fromfile,
    fromfunction as fromfunction,
    fromiter as fromiter,
    fromstring as fromstring,
    from_dlpack as from_dlpack,
    gcd as gcd,
    get_printoptions as get_printoptions,
    hsplit as hsplit,
    hstack as hstack,
    identity as identity,
    iinfo as iinfo,
    indices as indices,
    insert as insert,
    interp as interp,
    isscalar as isscalar,
    issubdtype as issubdtype,
    lcm as lcm,
    load as load,
    mask_indices as mask_indices,
    matrix_transpose as matrix_transpose,
    meshgrid as meshgrid,
    moveaxis as moveaxis,
    nonzero as nonzero,
    packbits as packbits,
    pad as pad,
    permute_dims as permute_dims,
    piecewise as piecewise,
    printoptions as printoptions,
    promote_types as promote_types,
    ravel as ravel,
    ravel_multi_index as ravel_multi_index,
    repeat as repeat,
    reshape as reshape,
    resize as resize,
    result_type as result_type,
    searchsorted as searchsorted,
    select as select,
    set_printoptions as set_printoptions,
    split as split,
    squeeze as squeeze,
    stack as stack,
    swapaxes as swapaxes,
    tile as tile,
    trace as trace,
    trapezoid as trapezoid,
    transpose as transpose,
    tri as tri,
    tril as tril,
    tril_indices as tril_indices,
    tril_indices_from as tril_indices_from,
    trim_zeros as trim_zeros,
    triu as triu,
    triu_indices as triu_indices,
    triu_indices_from as triu_indices_from,
    trunc as trunc,
    unpackbits as unpackbits,
    unravel_index as unravel_index,
    unstack as unstack,
    unwrap as unwrap,
    vsplit as vsplit,
    vstack as vstack,
    where as where,
)

from jax._src.numpy.array_creation import (
    empty as empty,
    empty_like as empty_like,
    full as full,
    full_like as full_like,
    linspace as linspace,
    ones as ones,
    ones_like as ones_like,
    zeros as zeros,
    zeros_like as zeros_like,
)

from jax._src.numpy.indexing import (
    place as place,
    put as put,
    put_along_axis as put_along_axis,
    take as take,
)

from jax._src.numpy.scalar_types import (
    bool_ as bool,  # Array API alias for bool_  # noqa: F401
    bool_ as bool_,
    int2 as int2,
    int4 as int4,
    int8 as int8,
    int16 as int16,
    int32 as int32,
    int64 as int64,
    int_ as int_,
    uint as uint,
    uint2 as uint2,
    uint4 as uint4,
    uint8 as uint8,
    uint16 as uint16,
    uint32 as uint32,
    uint64 as uint64,
)

from jax._src.numpy.sorting import (
    argpartition as argpartition,
    argsort as argsort,
    lexsort as lexsort,
    partition as partition,
    sort as sort,
)

from jax._src.numpy.tensor_contractions import (
  dot as dot,
  inner as inner,
  matmul as matmul,
  matvec as matvec,
  outer as outer,
  tensordot as tensordot,
  vecdot as vecdot,
  vecmat as vecmat,
  vdot as vdot,
)

from jax._src.numpy.util import (
  ndim as ndim,
  shape as shape,
  size as size,
)

# Some APIs come directly from NumPy:
from numpy import (
    array_repr as array_repr,
    array_str as array_str,
    character as character,
    dtype as dtype,
    e as e,
    euler_gamma as euler_gamma,
    flexible as flexible,
    generic as generic,
    inexact as inexact,
    integer as integer,
    iterable as iterable,
    newaxis as newaxis,
    number as number,
    object_ as object_,
    save as save,
    savez as savez,
    signedinteger as signedinteger,
    unsignedinteger as unsignedinteger,
)

from jax._src.numpy.array_api_metadata import (
  __array_api_version__ as __array_api_version__,
  __array_namespace_info__ as __array_namespace_info__,
)

from jax._src.numpy.index_tricks import (
  c_ as c_,
  index_exp as index_exp,
  mgrid as mgrid,
  ogrid as ogrid,
  r_ as r_,
  s_ as s_,
)

from jax._src.numpy.polynomial import (
    polyadd as polyadd,
    polydiv as polydiv,
    polymul as polymul,
    polysub as polysub,
    polyval as polyval,
)

from jax._src.numpy.reductions import (
    amin as amin,
    amax as amax,
    any as any,
    all as all,
    count_nonzero as count_nonzero,
    cumprod as cumprod,
    min as min,
    prod as prod,
    sum as sum,
)

from jax._src.numpy.setops import (
    intersect1d as intersect1d,
    isin as isin,
    setdiff1d as setdiff1d,
    setxor1d as setxor1d,
    union1d as union1d,
    unique as unique,
    unique_all as unique_all,
    unique_counts as unique_counts,
    unique_inverse as unique_inverse,
    unique_values as unique_values,
)

from jax._src.numpy.ufuncs import (
    abs as abs,
    absolute as absolute,
    add as add,
    bitwise_and as bitwise_and,
    bitwise_count as bitwise_count,
    bitwise_invert as bitwise_invert,
    bitwise_left_shift as bitwise_left_shift,
    bitwise_not as bitwise_not,
    bitwise_right_shift as bitwise_right_shift,
    bitwise_or as bitwise_or,
    bitwise_xor as bitwise_xor,
    copysign as copysign,
    divide as divide,
    divmod as divmod,
    equal as equal,
    floor_divide as floor_divide,
    greater as greater,
    greater_equal as greater_equal,
    invert as invert,
    left_shift as left_shift,
    less as less,
    less_equal as less_equal,
    logical_and as logical_and,
    logical_not as logical_not,
    logical_or as logical_or,
    logical_xor as logical_xor,
    maximum as maximum,
    minimum as minimum,
    mod as mod,
    multiply as multiply,
    negative as negative,
    not_equal as not_equal,
    positive as positive,
    pow as pow,
    power as power,
    remainder as remainder,
    right_shift as right_shift,
    sign as sign,
    signbit as signbit,
    spacing as spacing,
    square as square,
    subtract as subtract,
    true_divide as true_divide,
)

from jax._src.numpy.ufunc_api import (
    frompyfunc as frompyfunc,
    ufunc as ufunc,
)

from jax._src.numpy.vectorize import vectorize as vectorize

# Dynamically register numpy-style methods on JAX arrays.
from jax._src.numpy.array_methods import register_jax_array_methods
register_jax_array_methods()
del register_jax_array_methods
