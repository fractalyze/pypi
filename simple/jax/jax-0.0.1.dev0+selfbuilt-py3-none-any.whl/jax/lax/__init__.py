# Copyright 2019 The JAX Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Note: import <name> as <name> is required for names to be exported.
# See PEP 484 & https://github.com/jax-ml/jax/issues/7570

from jax._src.lax.lax import (
  abs as abs,
  abs_p as abs_p,
  add as add,
  add_p as add_p,
  after_all as after_all,
  after_all_p as after_all_p,
  and_p as and_p,
  argmax as argmax,
  argmax_p as argmax_p,
  argmin as argmin,
  argmin_p as argmin_p,
  batch_matmul as batch_matmul,
  bitcast_convert_type as bitcast_convert_type,
  bitcast_convert_type_p as bitcast_convert_type_p,
  bitwise_and as bitwise_and,
  bitwise_not as bitwise_not,
  bitwise_or as bitwise_or,
  bitwise_xor as bitwise_xor,
  broadcast as broadcast,
  broadcast_in_dim as broadcast_in_dim,
  broadcast_in_dim_p as broadcast_in_dim_p,
  broadcast_shapes as broadcast_shapes,
  broadcast_to_rank as broadcast_to_rank,
  broadcasted_iota as broadcasted_iota,
  clamp as clamp,
  clamp_p as clamp_p,
  clz as clz,
  clz_p as clz_p,
  collapse as collapse,
  composite as composite,
  concatenate as concatenate,
  concatenate_p as concatenate_p,
  convert_element_type as convert_element_type,
  convert_element_type_p as convert_element_type_p,
  copy_p as copy_p,
  dce_sink_p as dce_sink_p,
  dce_sink as dce_sink,
  create_token as create_token,
  create_token_p as create_token_p,
  div as div,
  div_p as div_p,
  dot as dot,
  dot_general as dot_general,
  dot_general_p as dot_general_p,
  DotDimensionNumbers as DotDimensionNumbers,
  dtype as dtype,
  eq as eq,
  eq_p as eq_p,
  eq_to_p as eq_to_p,
  expand_dims as expand_dims,
  full as full,
  full_like as full_like,
  ge as ge,
  ge_p as ge_p,
  gt as gt,
  gt_p as gt_p,
  integer_pow as integer_pow,
  integer_pow_p as integer_pow_p,
  iota as iota,
  iota_p as iota_p,
  le as le,
  le_p as le_p,
  le_to_p as le_to_p,
  lt as lt,
  lt_p as lt_p,
  lt_to_p as lt_to_p,
  max as max,
  max_p as max_p,
  min as min,
  min_p as min_p,
  mul as mul,
  mul_p as mul_p,
  ne as ne,
  ne_p as ne_p,
  neg as neg,
  neg_p as neg_p,
  not_p as not_p,
  optimization_barrier as optimization_barrier,
  optimization_barrier_p as optimization_barrier_p,
  or_p as or_p,
  pad as pad,
  pad_p as pad_p,
  padtype_to_pads as padtype_to_pads,
  population_count as population_count,
  population_count_p as population_count_p,
  pow as pow,
  pow_p as pow_p,
  # ragged_dot as ragged_dot,
  # ragged_dot_general as ragged_dot_general,
  reduce as reduce,
  reduce_and as reduce_and,
  reduce_and_p as reduce_and_p,
  reduce_max as reduce_max,
  reduce_max_p as reduce_max_p,
  reduce_min as reduce_min,
  reduce_min_p as reduce_min_p,
  reduce_or as reduce_or,
  reduce_or_p as reduce_or_p,
  reduce_p as reduce_p,
  reduce_prod as reduce_prod,
  reduce_prod_p as reduce_prod_p,
  reduce_sum as reduce_sum,
  reduce_sum_p as reduce_sum_p,
  reduce_xor as reduce_xor,
  reduce_xor_p as reduce_xor_p,
  rem as rem,
  rem_p as rem_p,
  reshape as reshape,
  reshape_p as reshape_p,
  rev as rev,
  rev_p as rev_p,
  bit_reverse as bit_reverse,
  bit_reverse_p as bit_reverse_p,
  select as select,
  select_n as select_n,
  select_n_p as select_n_p,
  shape_as_value as shape_as_value,
  shift_left as shift_left,
  shift_left_p as shift_left_p,
  shift_right_arithmetic as shift_right_arithmetic,
  shift_right_arithmetic_p as shift_right_arithmetic_p,
  shift_right_logical as shift_right_logical,
  shift_right_logical_p as shift_right_logical_p,
  sign as sign,
  sign_p as sign_p,
  sort as sort,
  sort_key_val as sort_key_val,
  sort_p as sort_p,
  split as split,
  split_p as split_p,
  square as square,
  square_p as square_p,
  squeeze as squeeze,
  squeeze_p as squeeze_p,
  sub as sub,
  sub_p as sub_p,
  transpose as transpose,
  transpose_p as transpose_p,
  xor_p as xor_p,
  empty as empty,
  zeros_like_array as _deprecated_zeros_like_array,
)
from jax._src.lax.slicing import (
  GatherDimensionNumbers as GatherDimensionNumbers,
  GatherScatterMode as GatherScatterMode,
  ScatterDimensionNumbers as ScatterDimensionNumbers,
  dynamic_index_in_dim as dynamic_index_in_dim,
  dynamic_slice as dynamic_slice,
  dynamic_slice_in_dim as dynamic_slice_in_dim,
  dynamic_slice_p as dynamic_slice_p,
  dynamic_update_index_in_dim as dynamic_update_index_in_dim,
  dynamic_update_slice as dynamic_update_slice,
  dynamic_update_slice_in_dim as dynamic_update_slice_in_dim,
  dynamic_update_slice_p as dynamic_update_slice_p,
  gather as gather,
  gather_p as gather_p,
  index_in_dim as index_in_dim,
  index_take as index_take,
  scatter as scatter,
  scatter_apply as scatter_apply,
  scatter_add as scatter_add,
  scatter_add_p as scatter_add_p,
  scatter_max as scatter_max,
  scatter_max_p as scatter_max_p,
  scatter_min as scatter_min,
  scatter_min_p as scatter_min_p,
  scatter_mul as scatter_mul,
  scatter_mul_p as scatter_mul_p,
  scatter_p as scatter_p,
  scatter_sub as scatter_sub,
  scatter_sub_p as scatter_sub_p,
  slice as slice,
  slice_in_dim as slice_in_dim,
  slice_p as slice_p,
)
from jax._src.lax.control_flow import (
  associative_scan as associative_scan,
  cond as cond,
  cond_p as cond_p,
  fori_loop as fori_loop,
  map as map,
  scan as scan,
  scan_p as scan_p,
  switch as switch,
  while_loop as while_loop,
  while_p as while_p,
  platform_dependent as platform_dependent,
)
from jax._src.core import (
    pvary as pvary,
)

# TODO(chokobole): Uncomment this. Dependency: pjit
# from jax._src.pjit import with_sharding_constraint as with_sharding_constraint
# from jax._src.pjit import sharding_constraint_p as sharding_constraint_p
# from jax._src.dispatch import device_put_p as device_put_p

_deprecations = {
    # Added on July 24th 2025.
    "zeros_like_array": (
        (
            "jax.lax.zeros_like_array is deprecated. Use jax.numpy.zeros_like instead."
        ),
        _deprecated_zeros_like_array,
    ),
}

import typing as _typing
if _typing.TYPE_CHECKING:
  zeros_like_array = _deprecated_zeros_like_array
else:
  from jax._src.deprecations import deprecation_getattr as _deprecation_getattr
  __getattr__ = _deprecation_getattr(__name__, _deprecations)
  del _deprecation_getattr
del _deprecated_zeros_like_array
del _typing
