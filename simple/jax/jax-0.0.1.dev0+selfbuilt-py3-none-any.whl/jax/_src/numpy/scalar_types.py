# Copyright 2025 The JAX Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.



# At present JAX doesn't have a reason to distinguish between scalars and arrays
# in its object system. Further, we want JAX scalars to have the same type
# promotion behaviors as JAX arrays. Rather than introducing a new type of JAX
# scalar object with JAX promotion behaviors, instead we make the JAX scalar
# types return JAX arrays when instantiated.

from typing import Any

import numpy as np
from zk_dtypes import bn254_g1_affine, bn254_g2_jacobian, goldilocks, mersenne31

from jax._src.typing import Array
from jax._src import core
from jax._src import dtypes
from jax._src.numpy.array_constructors import asarray


# Some objects below rewrite their __module__ attribute to this name.
_PUBLIC_MODULE_NAME = "jax.numpy"


class _ScalarMeta(type):
  dtype: np.dtype

  def __hash__(self) -> int:
    return hash(self.dtype.type)

  def __eq__(self, other: Any) -> bool:
    return self is other or self.dtype.type == other

  def __ne__(self, other: Any) -> bool:
    return not (self == other)

  def __call__(self, x: Any) -> Array:
    return asarray(x, dtype=self.dtype)

  def __instancecheck__(self, instance: Any) -> bool:
    return isinstance(instance, self.dtype.type)

def _abstractify_scalar_meta(x):
  raise TypeError(f"JAX scalar type {x} cannot be interpreted as a JAX array.")
core.pytype_aval_mappings[_ScalarMeta] = _abstractify_scalar_meta

def _make_scalar_type(np_scalar_type: type) -> _ScalarMeta:
  meta = _ScalarMeta(np_scalar_type.__name__, (object,),
                     {"dtype": np.dtype(np_scalar_type)})
  meta.__module__ = _PUBLIC_MODULE_NAME
  meta.__doc__ =\
  f"""A JAX scalar constructor of type {np_scalar_type.__name__}.

  While NumPy defines scalar types for each data type, JAX represents
  scalars as zero-dimensional arrays.
  """
  return meta

bool_ = _make_scalar_type(np.bool_)
uint2 = _make_scalar_type(dtypes.uint2)
uint4 = _make_scalar_type(dtypes.uint4)
uint8 = _make_scalar_type(np.uint8)
uint16 = _make_scalar_type(np.uint16)
uint32 = _make_scalar_type(np.uint32)
uint64 = _make_scalar_type(np.uint64)
int2 = _make_scalar_type(dtypes.int2)
int4 = _make_scalar_type(dtypes.int4)
int8 = _make_scalar_type(np.int8)
int16 = _make_scalar_type(np.int16)
int32 = _make_scalar_type(np.int32)
int64 = _make_scalar_type(np.int64)
babybear = _make_scalar_type(dtypes.babybear)
babybear_mont = _make_scalar_type(dtypes.babybear_mont)
goldilocks = _make_scalar_type(dtypes.goldilocks)
goldilocks_mont = _make_scalar_type(dtypes.goldilocks_mont)
koalabear = _make_scalar_type(dtypes.koalabear)
koalabear_mont = _make_scalar_type(dtypes.koalabear_mont)
mersenne31 = _make_scalar_type(dtypes.mersenne31)
bn254_sf = _make_scalar_type(dtypes.bn254_sf)
bn254_sf_mont = _make_scalar_type(dtypes.bn254_sf_mont)
bn254_g1_affine = _make_scalar_type(dtypes.bn254_g1_affine)
bn254_g1_affine_mont = _make_scalar_type(dtypes.bn254_g1_affine_mont)
bn254_g1_jacobian = _make_scalar_type(dtypes.bn254_g1_jacobian)
bn254_g1_jacobian_mont = _make_scalar_type(dtypes.bn254_g1_jacobian_mont)
bn254_g1_xyzz = _make_scalar_type(dtypes.bn254_g1_xyzz)
bn254_g1_xyzz_mont = _make_scalar_type(dtypes.bn254_g1_xyzz_mont)
bn254_g2_affine = _make_scalar_type(dtypes.bn254_g2_affine)
bn254_g2_affine_mont = _make_scalar_type(dtypes.bn254_g2_affine_mont)
bn254_g2_jacobian = _make_scalar_type(dtypes.bn254_g2_jacobian)
bn254_g2_jacobian_mont = _make_scalar_type(dtypes.bn254_g2_jacobian_mont)
bn254_g2_xyzz = _make_scalar_type(dtypes.bn254_g2_xyzz)
bn254_g2_xyzz_mont = _make_scalar_type(dtypes.bn254_g2_xyzz_mont)

int_ = int32 if dtypes.int_ == np.int32 else int64
uint = uint32 if dtypes.uint == np.uint32 else uint64
